package com.ajcompare.domain;

import java.util.UUID;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Product {
    @Id
    @GeneratedValue(generator = "UUID")
    private UUID id;
    private String name;
    private String url;
    private Double price;

    public Product() {

    }

    public Product(String name, String url, Double price){
        this.name = name;
        this.url = url;
        this.price = price;
    }

    public UUID getId() { return id; }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public String getUrl() { return url; }

    public void setUrl(String url) { this.url = url; }

    public Double getPrice() { return price; }

    public void setPrice(Double price) { this.price = price; }
}
