package com.ajcompare.resources;

import com.ajcompare.domain.Product;
import com.ajcompare.service.ProductService;
import io.quarkus.logging.Log;

import java.util.*;
import java.net.URI;

import javax.inject.Inject;
import javax.persistence.GeneratedValue;
import javax.transaction.Transactional;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;

@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/api/products")
public class ProductResource {

    @Inject
    private ProductService productService;

    public ProductResource(){
    }

    @GET
    public List<Product> allProducts() {
        return productService.allProducts();
    }

    @POST
    public Response addProduct(Product product) {
        Product productWithId = productService.addProduct(product);
        return Response.created(URI.create("/products/" + productWithId.getId())).build();
    }
}
