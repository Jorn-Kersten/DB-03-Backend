package com.ajcompare.service;

import com.ajcompare.domain.Product;
import com.ajcompare.repository.ProductRepository;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.transaction.Transactional;
import java.util.List;

@ApplicationScoped
public class ProductService {

    @Inject
    ProductRepository productRepository;

    public ProductService() {
    }

    public List<Product> allProducts() {
        return productRepository.listAll();
    }

    @Transactional
    public Product addProduct(Product product) {
        productRepository.persist(product);
        return product;
    }
}
