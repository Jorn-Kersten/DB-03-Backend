package com.ajcompare;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class ExampleResourceIT extends ExampleResourceTest {
    // Execute the same tests but in packaged mode.
}
